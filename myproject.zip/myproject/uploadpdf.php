<html>
<body>
<?php
//$id='9';
$host='localhost';
$user='root';
$pass='';
$conn=mysqli_connect($host,$user,$pass);
 if($conn)
 echo "connected succesfully";
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
//$name= . basename($_FILES["fileToUpload"]["name"]);
$name=$_FILES["fileToUpload"]["name"];

// Check if image file is a actual image or fake image
if(isset($_POST["expiry"],$_FILES["fileToUpload"])) {
	$file_name=mysql_real_escape_string($_FILES["fileToUpload"]["name"]);
	$expiry=time()+((int)$_POST["expiry"]*60);
	$target_dir = "uploads/";
     $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    /*$sql="insert into mydb.files(name,Location) value('$name','$target_file')";
        $query=mysqli_query($conn,$sql);
        if($query)
	    echo "inserted succesfully";*/
	    
   // $check = filesize($_FILES["fileToUpload"]["tmp_name"]);
	$finfo = finfo_open(FILEINFO_MIME_TYPE);   //only for pdf
    $mime = finfo_file($finfo, $_FILES["fileToUpload"]["tmp_name"]); //only for pdf if u want to upload image then remove 9 n 10th line.
   if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 50000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "pdf" && $imageFileType != "mp4") {
    echo "Sorry, only JPG, JPEG, pdf,mp4 & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        //echo "The file " $name . " has been uploaded.";
		$sql="insert into mydb.files values('','$name','$target_file',$expiry,'$rsel','$rdetail')";
		
        $query=mysqli_query($conn,$sql);
		//echo  "$sql";
        if($query)
	    echo "inserted succesfully";
		//echo "The file " .'$name' ." has been uploaded.";
        echo $name;
		
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

?>
<a href="display.php">display</a></br>
</body>
</html>